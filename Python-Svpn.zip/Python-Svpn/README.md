Python-Svpn  based on IPsec tunnel

Use the virtual network interface tun configuration under Linux. If you need to use it under Windows, please install wintun and modify the corresponding code.

Pip3 install required library functions in requirements.txt

sudo root and python3 svpn.py to start

log.txt is the traffic analysis log