function svpn() {
    chmod +x svpn.py
    echo "#!/usr/bin/env python3" | cat - svpn.py > temp && mv temp svpn.py
    export PATH="$PWD:$PATH"
    echo "Restart your terminal or run 'source ~/.bashrc' (or 'source ~/.zshrc' if using Zsh)"
}
